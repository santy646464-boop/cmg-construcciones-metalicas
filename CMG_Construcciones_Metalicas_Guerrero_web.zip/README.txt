C.M.G. CONSTRUCCIONES METÁLICAS GUERRERO
Sitio web inicial

Archivo principal: index.html

Para publicar en GitHub Pages:
1. Crear un repositorio público llamado, por ejemplo: cmg-construcciones-metalicas.
2. Subir index.html a la rama principal.
3. En Settings > Pages, seleccionar Deploy from a branch, rama main y carpeta /root.
4. Guardar y esperar la publicación.

El botón de WhatsApp ya está configurado para el número 0992655243.
La galería contiene espacios provisionales para reemplazar con fotografías reales.
